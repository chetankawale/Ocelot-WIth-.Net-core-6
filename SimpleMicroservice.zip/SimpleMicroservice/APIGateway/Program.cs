
using Ocelot.DependencyInjection;
using Ocelot.Middleware;

var builder =  WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Configuration.AddJsonFile("ocelot.json");
builder.Services.AddOcelot();

 var  app =  builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();
app.MapControllers();

//Ocelot
await app.UseOcelot();
app.Run();
